 
package MobileRepair;

 
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Thato Maphalla
 */

public class Mobile extends javax.swing.JFrame {

    /**
     * Creates new form Mobile
     */
    public Mobile() {
        this.setLocationRelativeTo(null);
        initComponents();
        table_display();
        AutoID();
    }

    private Connection con1;
    PreparedStatement insert;
    
   

    public void Connection() throws SQLException {

        try {
            Class.forName("com.mysql.jdbc.Driver");
              con1 = DriverManager.getConnection("jdbc:mysql://localhost/repairshop","root","");
 

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void AutoID() {

        try {
            Connection();
            Statement s = con1.createStatement();
            ResultSet rs = s.executeQuery("select MAX(repairNo)from repair");
            rs.next();
            rs.getString("MAX(repairNo)");

            if (rs.getString("MAX(repairNo)").equals("")) {
                txtRNO.setText("RE00001");
            }
            else if (rs.getString("MAX(repairNo)").equals("RE10000")) {
                txtRNO.setText("RE00001");
            }
            else {
                long id = Long.parseLong(rs.getString("MAX(repairNo)").substring(2, rs.getString("MAX(repairNo)").length()));
                id++;
                txtRNO.setText("RE" + String.format("%05d", id));
            }

        } catch (SQLException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public boolean Print() {
        //START OF VALIDATION IF ELSE STATEMENT         
        if (txtName.getText().isEmpty() || txtPhone.getText().isEmpty() || txtPhone.getText().isEmpty() || txtModel.getText().isEmpty() || txtSN.getText().isEmpty() || txtProblem.getText().isEmpty() || txtPrice.getText().isEmpty() || txtAmount.getText().isEmpty()) {

            JOptionPane.showMessageDialog(this, "NO FILLED CAN BE EMPTY");
            return false;
        } else {

            String repairNo = txtRNO.getText();
            String Name = txtName.getText();
            String Phone = txtPhone.getText();
            String Model = txtModel.getText();
            String SN = txtSN.getText();
            String Problem = txtProblem.getText();
            String Price = txtPrice.getText();
            String Amount = txtAmount.getText();
            String Due = txtDue.getText();
            String Status = txtStatus.getSelectedItem().toString();

            try {

                insert = con1.prepareStatement("INSERT INTO repair(repairNo,name,phone,model,sn,problem,price,amount,due,status)values(?,?,?,?,?,?,?,?,?,?)");
                insert.setString(1, repairNo);
                insert.setString(2, Name);
                insert.setString(3, Phone);
                insert.setString(4, Model);
                insert.setString(5, SN);
                insert.setString(6, Problem);
                insert.setString(7, Price);
                insert.setString(8, Amount);
                insert.setString(9, Due);
                insert.setString(10, Status);
                insert.executeUpdate();

                JOptionPane.showMessageDialog(this, "RECORD ADDED");
                Connection();
                AutoID();
                table_display();

                txtRNO.setText("");
                txtName.setText("");
                txtPhone.setText("");
                txtModel.setText("");
                txtSN.setText("");
                txtProblem.setText("");
                txtPrice.setText("");
                txtAmount.setText("");
                txtDue.setText("");
                txtStatus.setSelectedItem(-1);
                txtName.requestFocus();

            } catch (SQLException ex) {
                Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
            }
        }//END OF VALIDATION IF ELSE STATEMENT
        return true;
    }

    private void table_display() {
        int c;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con1 = (DriverManager.getConnection("jdbc:mysql://localhost/repairshop", "root", ""));
            insert = con1.prepareStatement("SELECT * FROM repair");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
            Df.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int a = 1; a <= c; a++) {
                    v2.add(rs.getString("repairNo"));
                    v2.add(rs.getString("Name"));
                    v2.add(rs.getString("Phone"));
                    v2.add(rs.getString("Model"));
                    v2.add(rs.getString("SN"));
                    v2.add(rs.getString("Problem"));
                    v2.add(rs.getString("Price"));
                    v2.add(rs.getString("Amount"));
                    v2.add(rs.getString("Due"));
                    v2.add(rs.getString("Status"));
                }
                Df.addRow(v2);
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void printDoc() {
        String repairNo = txtRNO.getText();
        String Model = txtModel.getText();
        String SN = txtSN.getText();
        String Problem = txtProblem.getText();
        String Price = txtPrice.getText();
        String Amount = txtAmount.getText();
        String Due = txtDue.getText();

        new Print(repairNo, Model, SN, Problem, Price, Amount, Due).setVisible(true);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabelClose = new javax.swing.JLabel();
        jLabelMn = new javax.swing.JLabel();
        txtS = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtPhone = new javax.swing.JTextField();
        txtModel = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtSN = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtProblem = new javax.swing.JTextPane();
        txtRNO = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        txtAbout = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtStatus = new javax.swing.JComboBox<>();
        txtPrice = new javax.swing.JTextField();
        txtAmount = new javax.swing.JTextField();
        txtDue = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        Print = new javax.swing.JButton();
        Refresh = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Electronics Repairing Management System");
        setBackground(new java.awt.Color(0, 153, 153));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(0, 153, 153));
        jTextField1.setFont(new java.awt.Font("Arial Narrow", 2, 36)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(255, 255, 255));
        jTextField1.setText("ELECTRONICS REPAIR MANAGEMENT SYSTEM");
        jTextField1.setBorder(null);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabelClose.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabelClose.setForeground(new java.awt.Color(255, 0, 0));
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabelMn.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabelMn.setForeground(new java.awt.Color(255, 255, 255));
        jLabelMn.setText("-");
        jLabelMn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMnMouseClicked(evt);
            }
        });

        txtS.setFont(new java.awt.Font("Arial Rounded MT Bold", 2, 12)); // NOI18N
        txtS.setText("Search");
        txtS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtSMouseEntered(evt);
            }
        });
        txtS.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtSInputMethodTextChanged(evt);
            }
        });
        txtS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSActionPerformed(evt);
            }
        });
        txtS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSKeyTyped(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("Search :");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 705, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtS, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelMn, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabelClose)
                .addGap(18, 18, 18))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtS, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelClose)
                    .addComponent(jLabelMn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtS.getAccessibleContext().setAccessibleName("");
        txtS.getAccessibleContext().setAccessibleDescription("");

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.white, java.awt.Color.white), "Device Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel1.setText("Repair No");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(16, 55, 67, 15);

        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel2.setText("Customer Name");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(16, 121, 107, 15);

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel3.setText("Customer Phone No");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(16, 194, 132, 15);

        jLabel4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel4.setText("Model No");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(16, 270, 62, 15);

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        jLabel6.setText("Problem");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(130, 380, 110, 29);

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel5.setText("Serial No");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(16, 345, 61, 15);

        txtPhone.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jPanel1.add(txtPhone);
        txtPhone.setBounds(158, 175, 195, 34);

        txtModel.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jPanel1.add(txtModel);
        txtModel.setBounds(158, 251, 195, 34);

        txtName.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });
        jPanel1.add(txtName);
        txtName.setBounds(158, 102, 195, 34);

        txtSN.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        txtSN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSNActionPerformed(evt);
            }
        });
        jPanel1.add(txtSN);
        txtSN.setBounds(158, 326, 195, 34);

        txtProblem.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jScrollPane1.setViewportView(txtProblem);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 410, 350, 130);

        txtRNO.setBackground(new java.awt.Color(255, 255, 255));
        txtRNO.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        txtRNO.setForeground(new java.awt.Color(255, 255, 255));
        txtRNO.setText("RE000");
        jPanel1.add(txtRNO);
        txtRNO.setBounds(178, 50, 80, 21);

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));
        jPanel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 1, true));
        jPanel5.setLayout(null);

        txtAbout.setBackground(new java.awt.Color(204, 204, 204));
        txtAbout.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        txtAbout.setText("Author");
        txtAbout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtAbout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtAboutMouseClicked(evt);
            }
        });
        jPanel5.add(txtAbout);
        txtAbout.setBounds(0, 0, 50, 20);

        jPanel1.add(jPanel5);
        jPanel5.setBounds(20, 550, 50, 20);

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.white, new java.awt.Color(255, 255, 255)), "Payment", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel2.setLayout(null);

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel7.setText("Repair Price");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(16, 31, 84, 15);

        jLabel8.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel8.setText("Amount Payed");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(16, 88, 97, 15);

        jLabel9.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel9.setText("Amount Due");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(16, 144, 81, 15);

        jLabel10.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        jLabel10.setText("Status");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(16, 194, 43, 15);

        txtStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Complete" }));
        jPanel2.add(txtStatus);
        txtStatus.setBounds(149, 192, 108, 20);

        txtPrice.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jPanel2.add(txtPrice);
        txtPrice.setBounds(149, 20, 108, 31);

        txtAmount.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        txtAmount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtAmountKeyReleased(evt);
            }
        });
        jPanel2.add(txtAmount);
        txtAmount.setBounds(149, 69, 108, 31);

        txtDue.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jPanel2.add(txtDue);
        txtDue.setBounds(149, 128, 108, 31);

        jTable1.setBackground(new java.awt.Color(204, 204, 204));
        jTable1.setFont(new java.awt.Font("Arial Narrow", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Repair No", "CustomerName", "Phone No", "Model No", "Serial No", "Problem", "Repair Price", "Payed", "Due", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));
        jPanel3.setLayout(null);

        Print.setBackground(new java.awt.Color(0, 255, 255));
        Print.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Print.setText("Print");
        Print.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.white, java.awt.Color.black));
        Print.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Print.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintMouseClicked(evt);
            }
        });
        Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintActionPerformed(evt);
            }
        });
        jPanel3.add(Print);
        Print.setBounds(161, 66, 206, 50);

        Refresh.setBackground(new java.awt.Color(0, 255, 255));
        Refresh.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Refresh.setText("Refresh");
        Refresh.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.white, java.awt.Color.black));
        Refresh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Refresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RefreshMouseClicked(evt);
            }
        });
        jPanel3.add(Refresh);
        Refresh.setBounds(161, 149, 206, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2))
                        .addGap(12, 12, 12))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 322, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    private void txtSNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSNActionPerformed

    private void PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintActionPerformed
        // TODO add your handling code here:
         if (txtName.getText().isEmpty() || txtPhone.getText().isEmpty() || txtPhone.getText().isEmpty() || txtModel.getText().isEmpty() || txtSN.getText().isEmpty() || txtProblem.getText().isEmpty() || txtPrice.getText().isEmpty() || txtAmount.getText().isEmpty()) {

            JOptionPane.showMessageDialog(this, "Please Enter All Fields");
            
        }else
         {
        printDoc();
        Print();
         }
    }//GEN-LAST:event_PrintActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int selectedIndex = jTable1.getSelectedRow();
        DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
        String Status = d1.getValueAt(selectedIndex, 9).toString();

        if (Status.equals("Complete")) 
        {
            JOptionPane.showMessageDialog(this, "Payment Complete");
        } 
        else 
        {
            String repairNo = d1.getValueAt(selectedIndex, 0).toString();
            String Model = d1.getValueAt(selectedIndex, 3).toString();
            String SN = d1.getValueAt(selectedIndex, 4).toString();
            String Price = d1.getValueAt(selectedIndex, 6).toString();
            String Amount = d1.getValueAt(selectedIndex, 7).toString();
            String Due = d1.getValueAt(selectedIndex, 8).toString();

            new Bill(repairNo, Model, SN, Price, Amount, Due).setVisible(true);
            this.setVisible(false);
        }
          
           
        DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
        txtRNO.setText(Df.getValueAt(selectedIndex, 0).toString());
        txtName.setText(Df.getValueAt(selectedIndex, 1).toString());
        txtPhone.setText(Df.getValueAt(selectedIndex, 2).toString());
        txtModel.setText(Df.getValueAt(selectedIndex, 3).toString());
        txtSN.setText(Df.getValueAt(selectedIndex, 4).toString());
        txtProblem.setText(Df.getValueAt(selectedIndex, 5).toString());
        txtPrice.setText(Df.getValueAt(selectedIndex, 6).toString());
        txtAmount.setText(Df.getValueAt(selectedIndex, 7).toString());
        txtDue.setText(Df.getValueAt(selectedIndex, 8).toString());
        txtStatus.setSelectedItem(Df.getValueAt(selectedIndex, 9).toString());


    }//GEN-LAST:event_jTable1MouseClicked

    private void txtAmountKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAmountKeyReleased
        // TODO add your handling code here:
        int price = Integer.parseInt(txtPrice.getText());
        int amount = Integer.parseInt(txtAmount.getText());
        int tot = price - amount;
        txtDue.setText(String.valueOf(tot));
    }//GEN-LAST:event_txtAmountKeyReleased

    private void PrintMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_PrintMouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
         //Auther();
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jLabelMnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMnMouseClicked
        // TODO add your handling code here:
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMnMouseClicked

    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCloseMouseClicked
        // TODO add your handling code here:
//       int dialogResult = JOptionPane.showConfirmDialog(null,"Are you sure you want to exit?","Warning",JOptionPane.YES_NO_OPTION);
//        if(dialogResult == JOptionPane.YES_OPTION)
//          {
//            JOptionPane.showMessageDialog(this, "Thank you for using our system");
            System.exit(0);
//          }
//        else
//        {
//             JOptionPane.showMessageDialog(this, "Please continue");
//        }
//      
           
    }//GEN-LAST:event_jLabelCloseMouseClicked

    private void RefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RefreshMouseClicked
        try {
            // TODO add your handling code here:
             
                Connection();
                AutoID();
                table_display();
                txtName.setText("");
                txtPhone.setText("");
                txtModel.setText("");
                txtSN.setText("");
                txtProblem.setText("");
                txtPrice.setText("");
                txtAmount.setText("");
                txtDue.setText("");
                txtS.setText("Search");
                txtStatus.setSelectedItem("Active");
                txtName.requestFocus();
                new Author().setVisible(false);
                JOptionPane.showMessageDialog(this, "Data Refreshed");
        } catch (SQLException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        }
                
    }//GEN-LAST:event_RefreshMouseClicked

    private void txtSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSActionPerformed

    private void txtSKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSKeyTyped
        //USING THE SELECT QUERY AS A SEARCH STATEMENT
        int d;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con1 = (DriverManager.getConnection("jdbc:mysql://localhost/repairshop", "root", ""));
            insert = con1.prepareStatement("SELECT * FROM repair WHERE name = '"+txtS.getText()+"'     ");//USING THE SELECT QUERY AS A SEARCH STATEMENT
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            d = Rss.getColumnCount();
            DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
            Df.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int a = 1; a <= d; a++) {
                    v2.add(rs.getString("repairNo"));
                    v2.add(rs.getString("Name"));
                    v2.add(rs.getString("Phone"));
                    v2.add(rs.getString("Model"));
                    v2.add(rs.getString("SN"));
                    v2.add(rs.getString("Problem"));
                    v2.add(rs.getString("Price"));
                    v2.add(rs.getString("Amount"));
                    v2.add(rs.getString("Due"));
                    v2.add(rs.getString("Status"));
                }
                Df.addRow(v2);
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Mobile.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }//GEN-LAST:event_txtSKeyTyped

    private void txtSKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtSKeyPressed

    private void txtSInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtSInputMethodTextChanged
        // TODO add your handling code here:
     
    }//GEN-LAST:event_txtSInputMethodTextChanged

    private void txtSMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSMouseEntered
        // TODO add your handling code here:
  
    }//GEN-LAST:event_txtSMouseEntered

    private void txtAboutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAboutMouseClicked
        // TODO add your handling code here:
      new Author().setVisible(true);    
    }//GEN-LAST:event_txtAboutMouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Metal".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mobile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mobile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mobile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mobile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Mobile().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Print;
    private javax.swing.JButton Refresh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelMn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel txtAbout;
    private javax.swing.JTextField txtAmount;
    private javax.swing.JTextField txtDue;
    private javax.swing.JTextField txtModel;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextPane txtProblem;
    private javax.swing.JLabel txtRNO;
    private javax.swing.JTextField txtS;
    private javax.swing.JTextField txtSN;
    private javax.swing.JComboBox<String> txtStatus;
    // End of variables declaration//GEN-END:variables
 
}
